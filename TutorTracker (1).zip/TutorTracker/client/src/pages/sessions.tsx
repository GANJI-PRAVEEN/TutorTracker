import { useEffect } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { useQuery } from "@tanstack/react-query";
import AppHeader from "@/components/AppHeader";
import BottomNavigation from "@/components/BottomNavigation";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { getSessionStatus, formatSessionTime } from "@/lib/sessionUtils";

export default function Sessions() {
  const { toast } = useToast();
  const { user, isAuthenticated, isLoading } = useAuth();

  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  const { data: sessions = [], isLoading: sessionsLoading } = useQuery({
    queryKey: ['/api/sessions'],
    retry: false,
    enabled: !!user,
  });

  if (isLoading || sessionsLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p>Loading sessions...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return null;
  }

  const groupedSessions = sessions.reduce((groups: { [key: string]: typeof sessions }, session) => {
    const date = new Date(session.date).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    });
    if (!groups[date]) {
      groups[date] = [];
    }
    groups[date].push(session);
    return groups;
  }, {});

  return (
    <div className="max-w-md mx-auto bg-white min-h-screen relative">
      <AppHeader 
        user={user}
        currentRole="tutor"
        onRoleSwitch={() => {}}
      />

      <main className="pb-20 px-4 py-6">
        <div className="flex items-center justify-between mb-6">
          <h1 className="text-2xl font-bold text-gray-900">Session History</h1>
          <Badge variant="secondary">{sessions.length} sessions</Badge>
        </div>

        {Object.keys(groupedSessions).length === 0 ? (
          <Card>
            <CardContent className="py-12 text-center">
              <i className="fas fa-clock text-gray-400 text-4xl mb-4"></i>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">No Sessions Yet</h3>
              <p className="text-gray-600">
                Your tutoring sessions will appear here once you start teaching.
              </p>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-6">
            {Object.entries(groupedSessions).map(([date, dateSessions]) => (
              <div key={date}>
                <h2 className="text-lg font-semibold text-gray-900 mb-3">{date}</h2>
                <div className="space-y-3">
                  {dateSessions.map((session) => {
                    const { status, color, icon } = getSessionStatus(session);
                    
                    return (
                      <Card key={session.id}>
                        <CardContent className="p-4">
                          <div className="flex items-center justify-between mb-3">
                            <div className="flex items-center space-x-3">
                              <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                                session.status === 'completed' ? 'bg-secondary' : 
                                session.status === 'active' ? 'bg-primary' : 'bg-gray-400'
                              }`}>
                                <i className={`fas ${icon} text-white`}></i>
                              </div>
                              <div>
                                <div className="font-medium text-gray-900">Student Session</div>
                                <div className="text-sm text-gray-600">
                                  {session.startTime ? formatSessionTime(session.startTime, session.endTime) : 'Time not recorded'}
                                </div>
                              </div>
                            </div>
                            <div className="text-right">
                              <div className="font-semibold text-gray-900">
                                {session.duration || 0} min
                              </div>
                              <div className={`text-sm ${color}`}>
                                {status}
                              </div>
                            </div>
                          </div>

                          <div className="flex items-center justify-between text-sm">
                            <div className="flex items-center space-x-4">
                              {session.autoDetected && (
                                <div className="flex items-center space-x-1 text-green-600">
                                  <i className="fas fa-map-marker-alt text-xs"></i>
                                  <span>Auto-detected</span>
                                </div>
                              )}
                              {session.manualAdjustment && (
                                <div className="flex items-center space-x-1 text-amber-600">
                                  <i className="fas fa-edit text-xs"></i>
                                  <span>Manual adjustment</span>
                                </div>
                              )}
                              {session.compensation && session.compensation > 0 && (
                                <div className="flex items-center space-x-1 text-red-600">
                                  <i className="fas fa-exclamation-triangle text-xs"></i>
                                  <span>-{session.compensation} min</span>
                                </div>
                              )}
                            </div>
                            <div className="font-medium text-gray-900">
                              ₹{session.earnings || 0}
                            </div>
                          </div>

                          {session.adjustmentReason && (
                            <div className="mt-3 p-3 bg-gray-50 rounded-lg">
                              <div className="text-xs text-gray-600 mb-1">Adjustment Reason:</div>
                              <div className="text-sm text-gray-800">{session.adjustmentReason}</div>
                              {!session.parentApproved && (
                                <div className="text-xs text-amber-600 mt-1">
                                  <i className="fas fa-clock mr-1"></i>
                                  Pending parent approval
                                </div>
                              )}
                            </div>
                          )}
                        </CardContent>
                      </Card>
                    );
                  })}
                </div>
              </div>
            ))}
          </div>
        )}
      </main>

      <BottomNavigation />
    </div>
  );
}
