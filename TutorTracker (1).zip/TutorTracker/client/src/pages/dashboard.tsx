import { useEffect, useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { isUnauthorizedError } from "@/lib/authUtils";
import { calculateDistance } from "@/lib/geoUtils";
import AppHeader from "@/components/AppHeader";
import SessionStatusCard from "@/components/SessionStatusCard";
import BottomNavigation from "@/components/BottomNavigation";
import ManualAdjustmentModal from "@/components/ManualAdjustmentModal";
import StudentSetupModal from "@/components/StudentSetupModal";
import LocationSimulator from "@/components/LocationSimulator";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useGeolocation } from "@/hooks/useGeolocation";
import { useSessionTimer } from "@/hooks/useSessionTimer";

export default function Dashboard() {
  const { toast } = useToast();
  const { user, isAuthenticated, isLoading } = useAuth();
  const queryClient = useQueryClient();
  const [showManualModal, setShowManualModal] = useState(false);
  const [showStudentModal, setShowStudentModal] = useState(false);
  const [currentRole, setCurrentRole] = useState<'tutor' | 'parent'>('tutor');
  
  const { location, error: locationError, requestPermission } = useGeolocation();
  const { currentTime, isRunning, startTimer, stopTimer, resetTimer } = useSessionTimer();
  const [simulatedLocation, setSimulatedLocation] = useState<{latitude: number; longitude: number} | null>(null);

  // Redirect if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/auth/auto-login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  // Get active session
  const { data: activeSession, isLoading: sessionLoading } = useQuery({
    queryKey: ['/api/sessions/active'],
    retry: false,
    enabled: !!user && user?.roles?.includes('tutor'),
  });

  // Get weekly stats
  const { data: weeklyStats } = useQuery({
    queryKey: ['/api/analytics/weekly'],
    retry: false,
    enabled: !!user,
  });

  // Get recent sessions
  const { data: recentSessions = [] } = useQuery({
    queryKey: ['/api/sessions'],
    retry: false,
    enabled: !!user,
  });

  // Get compensations
  const { data: compensations = [] } = useQuery({
    queryKey: ['/api/compensations'],
    retry: false,
    enabled: !!user && user?.roles?.includes('tutor'),
  });

  // Get students
  const { data: students = [] } = useQuery({
    queryKey: ['/api/students'],
    retry: false,
    enabled: !!user,
    refetchInterval: 5000, // Refresh every 5 seconds for testing
  });

  // Start session mutation
  const startSessionMutation = useMutation({
    mutationFn: async (studentId: number) => {
      await apiRequest('POST', '/api/sessions/start', { studentId });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/sessions'] });
      startTimer();
      toast({
        title: "Session Started",
        description: "GPS tracking is now active.",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to start session.",
        variant: "destructive",
      });
    },
  });

  // End session mutation
  const endSessionMutation = useMutation({
    mutationFn: async (sessionId: number) => {
      const duration = Math.max(1, Math.floor(currentTime / 60)); // Convert seconds to minutes, minimum 1
      console.log('Ending session with duration:', duration, 'minutes');
      await apiRequest('POST', `/api/sessions/${sessionId}/end`, { duration });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/sessions'] });
      queryClient.invalidateQueries({ queryKey: ['/api/analytics/weekly'] });
      stopTimer();
      resetTimer();
      toast({
        title: "Session Ended",
        description: "Session has been completed successfully.",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to end session.",
        variant: "destructive",
      });
    },
  });

  // Use simulated location if available, otherwise use real GPS
  const currentLocation = simulatedLocation || location;

  // Start timer automatically if there's an active session
  useEffect(() => {
    if (activeSession && !isRunning) {
      console.log('Auto-starting timer for existing active session:', activeSession.id);
      startTimer();
    }
  }, [activeSession, isRunning, startTimer]);

  // Auto-start session based on GPS
  useEffect(() => {
    if (currentLocation && Array.isArray(students) && students.length > 0 && user?.roles?.includes('tutor')) {
      console.log('Checking GPS location for session detection...', {
        currentLocation,
        studentsCount: students.length,
        activeSession: activeSession?.id || 'none'
      });
      
      // Check if tutor is at any student's location
      students.forEach(student => {
        if (student.latitude && student.longitude) {
          const distance = calculateDistance(
            currentLocation.latitude,
            currentLocation.longitude,
            parseFloat(student.latitude),
            parseFloat(student.longitude)
          );
          
          console.log(`Distance to ${student.name}:`, distance, 'km');
          
          if (distance <= 0.1) { // Within 100 meters
            const today = new Date().toISOString().split('T')[0];
            const todaySession = recentSessions.find(
              s => s.studentId === student.id && s.date === today
            );
            
            console.log(`Found session for ${student.name} today:`, todaySession?.id || 'none');
            
            // If no active session but there's a session today, don't create duplicate
            if (!activeSession && !todaySession) {
              console.log('Creating new session for:', student.name);
              startSessionMutation.mutate(student.id);
            }
          }
        }
      });
    }
  }, [currentLocation, students, activeSession, recentSessions, user?.roles]);

  const handleLocationSimulation = (lat: number, lng: number) => {
    setSimulatedLocation({ latitude: lat, longitude: lng });
  };



  const formatTime = (seconds: number) => {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes}:${remainingSeconds.toString().padStart(2, '0')}`;
  };

  const handleRoleSwitch = () => {
    setCurrentRole(currentRole === 'tutor' ? 'parent' : 'tutor');
    // Refresh data when switching roles
    queryClient.invalidateQueries({ queryKey: ['/api/students'] });
    queryClient.invalidateQueries({ queryKey: ['/api/sessions'] });
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p>Loading...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return null;
  }

  return (
    <div className="max-w-md mx-auto bg-white min-h-screen relative">
      <AppHeader 
        user={user}
        currentRole={currentRole}
        onRoleSwitch={handleRoleSwitch}
      />

      <main className="pb-20">
        {currentRole === 'tutor' && (
          <>
            <SessionStatusCard
              activeSession={activeSession}
              currentTime={formatTime(currentTime)}
              isGpsActive={!!currentLocation}
              onEndSession={() => activeSession && endSessionMutation.mutate(activeSession.id)}
              onPauseSession={() => {}} // TODO: Implement pause functionality
            />
            
            <div className="px-4">
              {/* Debug: Show students data */}
              <div className="mb-4 p-2 bg-yellow-50 border border-yellow-200 rounded text-xs">
                <strong>Debug:</strong> Found {students.length} students - {students.map(s => s.name).join(', ')}
              </div>
              
              <LocationSimulator
                students={students}
                onLocationChange={handleLocationSimulation}
                currentLocation={currentLocation}
              />
            </div>
          </>
        )}

        {/* Compensation Alert */}
        {compensations.length > 0 && (
          <div className="px-4 mb-6">
            <div className="compensation-alert rounded-xl p-4 text-white">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <i className="fas fa-exclamation-triangle text-xl"></i>
                  <div>
                    <h3 className="font-semibold">Compensation Needed</h3>
                    <p className="text-amber-100 text-sm">
                      {compensations.reduce((sum, comp) => sum + comp.deficitMinutes, 0)} minutes shortfall
                    </p>
                  </div>
                </div>
                <Button 
                  variant="ghost" 
                  size="sm"
                  className="bg-white bg-opacity-20 hover:bg-white hover:bg-opacity-30"
                >
                  View Details
                </Button>
              </div>
            </div>
          </div>
        )}

        {/* Quick Stats */}
        <div className="px-4 mb-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">This Week</h3>
          <div className="grid grid-cols-2 gap-4">
            <Card>
              <CardContent className="p-4">
                <div className="text-2xl font-bold text-gray-900">
                  {weeklyStats?.totalMinutes || 0}
                </div>
                <div className="text-sm text-gray-600">Minutes Taught</div>
                <div className="text-xs text-secondary mt-1">
                  {weeklyStats?.totalMinutes >= 450 ? '+' : ''}
                  {(weeklyStats?.totalMinutes || 0) - 450} vs target
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-4">
                <div className="text-2xl font-bold text-gray-900">
                  ₹{weeklyStats?.totalEarnings || 0}
                </div>
                <div className="text-sm text-gray-600">Earnings</div>
                <div className="text-xs text-secondary mt-1">This week</div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-4">
                <div className="text-2xl font-bold text-gray-900">
                  {weeklyStats?.daysActive || 0}
                </div>
                <div className="text-sm text-gray-600">Days Active</div>
                <div className="text-xs text-gray-600 mt-1">Mon-Fri</div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-4">
                <div className="text-2xl font-bold text-accent">
                  {weeklyStats?.compensationMinutes ? `-${weeklyStats.compensationMinutes}` : '0'}
                </div>
                <div className="text-sm text-gray-600">To Compensate</div>
                <div className="text-xs text-gray-600 mt-1">Pending</div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Recent Sessions */}
        <div className="px-4 mb-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-gray-900">Recent Sessions</h3>
            <Button variant="ghost" size="sm">View All</Button>
          </div>
          
          {recentSessions.slice(0, 3).map((session, index) => (
            <Card key={index} className="mb-3">
              <CardContent className="p-4">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center space-x-3">
                    <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                      session.status === 'completed' ? 'bg-secondary' : 'bg-accent'
                    }`}>
                      <i className={`fas ${session.status === 'completed' ? 'fa-check' : 'fa-clock'} text-white`}></i>
                    </div>
                    <div>
                      <div className="font-medium text-gray-900">
                        {new Date(session.date).toLocaleDateString()}
                      </div>
                      <div className="text-sm text-gray-600">Student Session</div>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="font-semibold text-gray-900">{session.duration || 0} min</div>
                    <div className={`text-sm ${
                      session.status === 'completed' ? 'text-secondary' : 'text-accent'
                    }`}>
                      {session.status === 'completed' ? 'Complete' : 'Pending'}
                    </div>
                  </div>
                </div>
                <div className="flex items-center justify-between text-xs text-gray-500">
                  <span>
                    {session.startTime ? new Date(session.startTime).toLocaleTimeString() : 'Not started'}
                  </span>
                  <span>₹{session.earnings || 0}</span>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Student Setup or Quick Actions */}
        {students.length === 0 ? (
          <div className="px-4 mb-6">
            <Card className="bg-gradient-to-r from-primary/10 to-secondary/10 border-primary/20">
              <CardContent className="p-6 text-center">
                <i className="fas fa-user-plus text-primary text-3xl mb-4"></i>
                <h3 className="text-lg font-semibold text-gray-900 mb-2">Add Your First Student</h3>
                <p className="text-gray-600 mb-4">
                  Add a student's profile with their home address to enable GPS-based automatic session tracking.
                </p>
                <Button 
                  onClick={() => setShowStudentModal(true)}
                  className="w-full"
                >
                  <i className="fas fa-plus mr-2"></i>
                  Add Student
                </Button>
              </CardContent>
            </Card>
          </div>
        ) : (
          <div className="px-4 mb-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Quick Actions</h3>
            <div className="grid grid-cols-2 gap-3">
              <Button
                variant="outline"
                className="p-4 h-auto flex-col items-start"
                onClick={() => setShowManualModal(true)}
              >
                <i className="fas fa-edit text-primary text-lg mb-2"></i>
                <div className="font-medium text-gray-900">Manual Adjustment</div>
                <div className="text-xs text-gray-600">Edit session details</div>
              </Button>
              
              <Button
                variant="outline"
                className="p-4 h-auto flex-col items-start"
                onClick={() => setShowStudentModal(true)}
              >
                <i className="fas fa-user-plus text-primary text-lg mb-2"></i>
                <div className="font-medium text-gray-900">Add Student</div>
                <div className="text-xs text-gray-600">New student profile</div>
              </Button>
            </div>
          </div>
        )}
      </main>

      <BottomNavigation />
      
      <ManualAdjustmentModal
        isOpen={showManualModal}
        onClose={() => setShowManualModal(false)}
        recentSessions={recentSessions}
      />
      
      <StudentSetupModal
        isOpen={showStudentModal}
        onClose={() => setShowStudentModal(false)}
        tutorId={user.id}
      />
    </div>
  );
}
