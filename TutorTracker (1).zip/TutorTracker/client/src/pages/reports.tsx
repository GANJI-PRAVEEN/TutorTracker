import { useEffect } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { useQuery } from "@tanstack/react-query";
import AppHeader from "@/components/AppHeader";
import BottomNavigation from "@/components/BottomNavigation";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

export default function Reports() {
  const { toast } = useToast();
  const { user, isAuthenticated, isLoading } = useAuth();

  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  const { data: weeklyStats } = useQuery({
    queryKey: ['/api/analytics/weekly'],
    retry: false,
    enabled: !!user,
  });

  const { data: sessions = [] } = useQuery({
    queryKey: ['/api/sessions'],
    retry: false,
    enabled: !!user,
  });

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p>Loading reports...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return null;
  }

  const currentMonth = new Date().toLocaleDateString('en-US', { 
    year: 'numeric', 
    month: 'long' 
  });

  const currentMonthSessions = sessions.filter(session => {
    const sessionDate = new Date(session.date);
    const now = new Date();
    return sessionDate.getMonth() === now.getMonth() && 
           sessionDate.getFullYear() === now.getFullYear();
  });

  const monthlyStats = {
    totalDays: currentMonthSessions.filter(s => s.status === 'completed').length,
    totalMinutes: currentMonthSessions.reduce((sum, s) => sum + (s.duration || 0), 0),
    totalEarnings: currentMonthSessions.reduce((sum, s) => sum + Number(s.earnings || 0), 0),
    pendingCompensation: currentMonthSessions.reduce((sum, s) => {
      if (s.status === 'completed' && s.duration && s.duration < 90) {
        return sum + (90 - s.duration);
      }
      return sum;
    }, 0),
  };

  const handleExportReport = () => {
    toast({
      title: "Export Started",
      description: "Your report is being generated and will be downloaded shortly.",
    });
    // TODO: Implement actual export functionality
  };

  return (
    <div className="max-w-md mx-auto bg-white min-h-screen relative">
      <AppHeader 
        user={user}
        currentRole="tutor"
        onRoleSwitch={() => {}}
      />

      <main className="pb-20 px-4 py-6">
        <div className="flex items-center justify-between mb-6">
          <h1 className="text-2xl font-bold text-gray-900">Reports</h1>
          <Button size="sm" onClick={handleExportReport}>
            <i className="fas fa-download mr-2"></i>
            Export
          </Button>
        </div>

        {/* Current Month Report */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              {currentMonth} Report
              <Button variant="outline" size="sm" onClick={handleExportReport}>
                <i className="fas fa-download mr-1"></i>
                Export
              </Button>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-4 mb-4">
              <div>
                <div className="text-xl font-bold text-gray-900">{monthlyStats.totalDays}</div>
                <div className="text-sm text-gray-600">Days Taught</div>
              </div>
              <div>
                <div className="text-xl font-bold text-gray-900">{monthlyStats.totalMinutes}</div>
                <div className="text-sm text-gray-600">Total Minutes</div>
              </div>
              <div>
                <div className="text-xl font-bold text-secondary">₹{monthlyStats.totalEarnings}</div>
                <div className="text-sm text-gray-600">Total Earnings</div>
              </div>
              <div>
                <div className="text-xl font-bold text-accent">{monthlyStats.pendingCompensation}</div>
                <div className="text-sm text-gray-600">Pending Minutes</div>
              </div>
            </div>

            <div className="bg-gray-50 rounded-lg p-3">
              <div className="text-sm text-gray-600 mb-1">Payment Calculation</div>
              <div className="text-lg font-semibold text-gray-900">
                {monthlyStats.totalDays} days × ₹300 = ₹{monthlyStats.totalDays * 300}
                {monthlyStats.pendingCompensation > 0 && " (if compensated)"}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Weekly Overview */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>This Week</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <div className="text-xl font-bold text-gray-900">
                  {weeklyStats?.totalMinutes || 0}
                </div>
                <div className="text-sm text-gray-600">Minutes Taught</div>
                <div className="text-xs text-secondary mt-1">
                  {(weeklyStats?.totalMinutes || 0) >= 450 ? 'On track' : 'Behind target'}
                </div>
              </div>
              <div>
                <div className="text-xl font-bold text-gray-900">
                  ₹{weeklyStats?.totalEarnings || 0}
                </div>
                <div className="text-sm text-gray-600">Earnings</div>
                <div className="text-xs text-secondary mt-1">This week</div>
              </div>
              <div>
                <div className="text-xl font-bold text-gray-900">
                  {weeklyStats?.daysActive || 0}
                </div>
                <div className="text-sm text-gray-600">Days Active</div>
                <div className="text-xs text-gray-600 mt-1">Mon-Fri</div>
              </div>
              <div>
                <div className="text-xl font-bold text-accent">
                  {weeklyStats?.compensationMinutes ? `-${weeklyStats.compensationMinutes}` : '0'}
                </div>
                <div className="text-sm text-gray-600">To Compensate</div>
                <div className="text-xs text-gray-600 mt-1">Pending</div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Session Analysis */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>Session Analysis</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-600">Completion Rate</span>
                <span className="font-semibold">
                  {sessions.length > 0 
                    ? Math.round((sessions.filter(s => s.status === 'completed').length / sessions.length) * 100)
                    : 0
                  }%
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-600">Average Session Duration</span>
                <span className="font-semibold">
                  {sessions.length > 0
                    ? Math.round(sessions.reduce((sum, s) => sum + (s.duration || 0), 0) / sessions.length)
                    : 0
                  } min
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-600">On-time Sessions</span>
                <span className="font-semibold">
                  {sessions.length > 0
                    ? Math.round((sessions.filter(s => s.duration && s.duration >= 90).length / sessions.length) * 100)
                    : 0
                  }%
                </span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Export Options */}
        <Card>
          <CardHeader>
            <CardTitle>Export Options</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <Button 
                variant="outline" 
                className="w-full justify-start" 
                onClick={handleExportReport}
              >
                <i className="fas fa-file-pdf text-red-500 mr-3"></i>
                Export as PDF
              </Button>
              <Button 
                variant="outline" 
                className="w-full justify-start" 
                onClick={handleExportReport}
              >
                <i className="fas fa-file-excel text-green-500 mr-3"></i>
                Export as Excel
              </Button>
              <Button 
                variant="outline" 
                className="w-full justify-start" 
                onClick={handleExportReport}
              >
                <i className="fas fa-envelope text-blue-500 mr-3"></i>
                Email Report
              </Button>
            </div>
          </CardContent>
        </Card>
      </main>

      <BottomNavigation />
    </div>
  );
}
