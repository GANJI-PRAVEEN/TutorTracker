import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

export default function Landing() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/10 to-secondary/10 flex items-center justify-center p-4">
      <Card className="w-full max-w-md">
        <CardContent className="pt-6 text-center">
          <div className="w-20 h-20 bg-primary rounded-full flex items-center justify-center mx-auto mb-6">
            <i className="fas fa-graduation-cap text-white text-2xl"></i>
          </div>
          
          <h1 className="text-2xl font-bold text-gray-900 mb-2">TutorTrack</h1>
          <p className="text-gray-600 mb-8">
            AI-powered tutoring session tracker with GPS-based automatic timing
          </p>
          
          <div className="space-y-4 mb-8">
            <div className="flex items-center space-x-3 text-sm text-gray-600">
              <div className="w-2 h-2 bg-primary rounded-full"></div>
              <span>Automatic GPS-based session tracking</span>
            </div>
            <div className="flex items-center space-x-3 text-sm text-gray-600">
              <div className="w-2 h-2 bg-secondary rounded-full"></div>
              <span>Compensation management & alerts</span>
            </div>
            <div className="flex items-center space-x-3 text-sm text-gray-600">
              <div className="w-2 h-2 bg-accent rounded-full"></div>
              <span>Monthly payment calculations</span>
            </div>
          </div>
          
          <Button 
            className="w-full" 
            onClick={() => window.location.href = '/api/auth/auto-login'}
          >
            Get Started
          </Button>
          
          <p className="text-xs text-gray-500 mt-4">
            For tutors and parents
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
