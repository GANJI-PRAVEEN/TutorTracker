import { useEffect } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import AppHeader from "@/components/AppHeader";
import BottomNavigation from "@/components/BottomNavigation";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";

export default function Profile() {
  const { toast } = useToast();
  const { user, isAuthenticated, isLoading } = useAuth();

  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p>Loading profile...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return null;
  }

  const handleLogout = () => {
    window.location.href = '/api/logout';
  };

  return (
    <div className="max-w-md mx-auto bg-white min-h-screen relative">
      <AppHeader 
        user={user}
        currentRole="tutor"
        onRoleSwitch={() => {}}
      />

      <main className="pb-20 px-4 py-6">
        {/* Profile Header */}
        <Card className="mb-6">
          <CardContent className="pt-6">
            <div className="flex items-center space-x-4 mb-4">
              <img 
                src={user.profileImageUrl || "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&w=80&h=80&fit=crop&crop=face"} 
                alt="Profile" 
                className="w-16 h-16 rounded-full object-cover"
              />
              <div>
                <h2 className="text-xl font-semibold text-gray-900">
                  {user.firstName || 'User'} {user.lastName || ''}
                </h2>
                <p className="text-gray-600">{user.email}</p>
                <div className="flex items-center space-x-2 mt-1">
                  <div className={`w-2 h-2 rounded-full ${
                    user.role === 'tutor' ? 'bg-primary' : 'bg-secondary'
                  }`}></div>
                  <span className="text-sm text-gray-600 capitalize">{user.role}</span>
                </div>
              </div>
            </div>
            <Button variant="outline" size="sm" className="w-full">
              <i className="fas fa-edit mr-2"></i>
              Edit Profile
            </Button>
          </CardContent>
        </Card>

        {/* Settings */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>App Settings</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <div className="font-medium">GPS Tracking</div>
                <div className="text-sm text-gray-600">Automatic session detection</div>
              </div>
              <Switch defaultChecked />
            </div>
            
            <div className="flex items-center justify-between">
              <div>
                <div className="font-medium">Push Notifications</div>
                <div className="text-sm text-gray-600">Session reminders and alerts</div>
              </div>
              <Switch defaultChecked />
            </div>
            
            <div className="flex items-center justify-between">
              <div>
                <div className="font-medium">Auto-start Sessions</div>
                <div className="text-sm text-gray-600">Start when arriving at location</div>
              </div>
              <Switch defaultChecked />
            </div>
            
            <div className="flex items-center justify-between">
              <div>
                <div className="font-medium">Compensation Alerts</div>
                <div className="text-sm text-gray-600">Notify about shortfalls</div>
              </div>
              <Switch defaultChecked />
            </div>
          </CardContent>
        </Card>

        {/* Quick Actions */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>Quick Actions</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <Button variant="outline" className="w-full justify-start">
              <i className="fas fa-map-marker-alt text-primary mr-3"></i>
              Manage Student Locations
            </Button>
            
            <Button variant="outline" className="w-full justify-start">
              <i className="fas fa-calendar text-primary mr-3"></i>
              Schedule Settings
            </Button>
            
            <Button variant="outline" className="w-full justify-start">
              <i className="fas fa-bell text-primary mr-3"></i>
              Notification History
            </Button>
            
            <Button variant="outline" className="w-full justify-start">
              <i className="fas fa-download text-primary mr-3"></i>
              Export All Data
            </Button>
          </CardContent>
        </Card>

        {/* Help & Support */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>Help & Support</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <Button variant="ghost" className="w-full justify-start">
              <i className="fas fa-question-circle text-gray-500 mr-3"></i>
              FAQ & Help Center
            </Button>
            
            <Button variant="ghost" className="w-full justify-start">
              <i className="fas fa-envelope text-gray-500 mr-3"></i>
              Contact Support
            </Button>
            
            <Button variant="ghost" className="w-full justify-start">
              <i className="fas fa-star text-gray-500 mr-3"></i>
              Rate the App
            </Button>
            
            <Button variant="ghost" className="w-full justify-start">
              <i className="fas fa-shield-alt text-gray-500 mr-3"></i>
              Privacy Policy
            </Button>
          </CardContent>
        </Card>

        {/* Account Actions */}
        <Card>
          <CardContent className="pt-6 space-y-3">
            <Button 
              variant="outline" 
              className="w-full text-red-600 border-red-200 hover:bg-red-50"
              onClick={handleLogout}
            >
              <i className="fas fa-sign-out-alt mr-2"></i>
              Sign Out
            </Button>
            
            <div className="text-center text-xs text-gray-500 pt-2">
              TutorTrack v1.0.0
            </div>
          </CardContent>
        </Card>
      </main>

      <BottomNavigation />
    </div>
  );
}
