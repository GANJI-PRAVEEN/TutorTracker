import type { TutoringSession } from "@shared/schema";

export function calculateSessionEarnings(duration: number, dailyRate: number = 300): number {
  const expectedDuration = 90; // minutes
  return duration >= expectedDuration ? dailyRate : (duration / expectedDuration) * dailyRate;
}

export function calculateCompensationNeeded(sessions: TutoringSession[]): number {
  return sessions.reduce((total, session) => {
    if (session.status === 'completed' && session.duration && session.duration < 90) {
      return total + (90 - session.duration);
    }
    return total;
  }, 0);
}

export function isWeekend(date: Date): boolean {
  const day = date.getDay();
  return day === 0 || day === 6; // Sunday or Saturday
}

export function getWeekDateRange(): { start: string; end: string } {
  const today = new Date();
  const startOfWeek = new Date(today);
  startOfWeek.setDate(today.getDate() - today.getDay()); // Start from Sunday
  
  const endOfWeek = new Date(startOfWeek);
  endOfWeek.setDate(startOfWeek.getDate() + 6);

  return {
    start: startOfWeek.toISOString().split('T')[0],
    end: endOfWeek.toISOString().split('T')[0],
  };
}

export function getMonthDateRange(): { start: string; end: string } {
  const today = new Date();
  const startOfMonth = new Date(today.getFullYear(), today.getMonth(), 1);
  const endOfMonth = new Date(today.getFullYear(), today.getMonth() + 1, 0);

  return {
    start: startOfMonth.toISOString().split('T')[0],
    end: endOfMonth.toISOString().split('T')[0],
  };
}

export function formatSessionTime(startTime: string, endTime?: string): string {
  const start = new Date(startTime);
  const startFormatted = start.toLocaleTimeString('en-US', {
    hour: 'numeric',
    minute: '2-digit',
    hour12: true,
  });

  if (endTime) {
    const end = new Date(endTime);
    const endFormatted = end.toLocaleTimeString('en-US', {
      hour: 'numeric',
      minute: '2-digit',
      hour12: true,
    });
    return `${startFormatted} - ${endFormatted}`;
  }

  return `Started at ${startFormatted}`;
}

export function getSessionStatus(session: TutoringSession): {
  status: string;
  color: string;
  icon: string;
} {
  switch (session.status) {
    case 'completed':
      if (session.duration && session.duration >= 90) {
        return { status: 'Complete', color: 'text-secondary', icon: 'fa-check' };
      } else {
        return { status: 'Shortfall', color: 'text-accent', icon: 'fa-exclamation-triangle' };
      }
    case 'active':
      return { status: 'Active', color: 'text-primary', icon: 'fa-play' };
    case 'cancelled':
      return { status: 'Cancelled', color: 'text-red-500', icon: 'fa-times' };
    default:
      return { status: 'Scheduled', color: 'text-gray-500', icon: 'fa-calendar' };
  }
}
