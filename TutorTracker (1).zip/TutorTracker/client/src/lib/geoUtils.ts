// Calculate distance between two coordinates using Haversine formula
export function calculateDistance(
  lat1: number,
  lon1: number,
  lat2: number,
  lon2: number
): number {
  const R = 6371; // Radius of the Earth in kilometers
  const dLat = deg2rad(lat2 - lat1);
  const dLon = deg2rad(lon2 - lon1);
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(deg2rad(lat1)) * Math.cos(deg2rad(lat2)) *
    Math.sin(dLon / 2) * Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  const d = R * c; // Distance in kilometers
  return d;
}

function deg2rad(deg: number): number {
  return deg * (Math.PI / 180);
}

export function formatDistance(distanceKm: number): string {
  if (distanceKm < 1) {
    const meters = Math.round(distanceKm * 1000);
    return `${meters}m`;
  } else {
    return `${distanceKm.toFixed(1)}km`;
  }
}

export function getDistanceStatus(distanceKm: number): {
  status: 'at-location' | 'nearby' | 'away';
  color: string;
  icon: string;
} {
  const distanceMeters = distanceKm * 1000;
  
  if (distanceMeters <= 100) {
    return {
      status: 'at-location',
      color: 'text-green-600',
      icon: 'fa-check-circle'
    };
  } else if (distanceMeters <= 500) {
    return {
      status: 'nearby',
      color: 'text-yellow-600',
      icon: 'fa-exclamation-circle'
    };
  } else {
    return {
      status: 'away',
      color: 'text-red-600',
      icon: 'fa-times-circle'
    };
  }
}