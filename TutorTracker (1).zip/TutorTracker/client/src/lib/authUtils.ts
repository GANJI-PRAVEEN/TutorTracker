export function isUnauthorizedError(error: Error): boolean {
  return /^401: .*Unauthorized/.test(error.message);
}

// Handle logout by redirecting to auto-login
export function handleLogout() {
  window.location.href = '/api/auth/logout';
}