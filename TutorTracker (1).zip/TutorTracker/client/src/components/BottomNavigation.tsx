import { useLocation } from "wouter";

export default function BottomNavigation() {
  const [location, setLocation] = useLocation();

  const navigationItems = [
    { path: "/", icon: "fa-home", label: "Dashboard" },
    { path: "/sessions", icon: "fa-clock", label: "Sessions" },
    { path: "/reports", icon: "fa-chart-line", label: "Reports" },
    { path: "/profile", icon: "fa-user", label: "Profile" },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 max-w-md mx-auto bg-white border-t border-gray-200">
      <div className="flex">
        {navigationItems.map((item) => {
          const isActive = location === item.path;
          return (
            <button
              key={item.path}
              onClick={() => setLocation(item.path)}
              className="flex-1 py-3 px-2 text-center"
            >
              <i className={`fas ${item.icon} text-lg mb-1 ${
                isActive ? 'text-primary' : 'text-gray-400'
              }`}></i>
              <div className={`text-xs font-medium ${
                isActive ? 'text-primary' : 'text-gray-400'
              }`}>
                {item.label}
              </div>
            </button>
          );
        })}
      </div>
    </nav>
  );
}
