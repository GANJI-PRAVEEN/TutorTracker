import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import type { TutoringSession } from "@shared/schema";

interface ManualAdjustmentModalProps {
  isOpen: boolean;
  onClose: () => void;
  recentSessions: TutoringSession[];
}

export default function ManualAdjustmentModal({ 
  isOpen, 
  onClose, 
  recentSessions 
}: ManualAdjustmentModalProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [selectedSessionId, setSelectedSessionId] = useState<string>("");
  const [duration, setDuration] = useState<string>("");
  const [reason, setReason] = useState<string>("");

  const adjustSessionMutation = useMutation({
    mutationFn: async () => {
      if (!selectedSessionId || !duration || !reason) {
        throw new Error("All fields are required");
      }
      
      await apiRequest('POST', `/api/sessions/${selectedSessionId}/adjust`, {
        duration: parseInt(duration),
        reason,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/sessions'] });
      toast({
        title: "Adjustment Submitted",
        description: "Your adjustment request has been sent for parent approval.",
      });
      onClose();
      setSelectedSessionId("");
      setDuration("");
      setReason("");
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: error.message || "Failed to submit adjustment.",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    adjustSessionMutation.mutate();
  };

  const completedSessions = recentSessions.filter(s => s.status === 'completed');

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Manual Adjustment</DialogTitle>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <Label htmlFor="session">Select Session</Label>
            <Select value={selectedSessionId} onValueChange={setSelectedSessionId}>
              <SelectTrigger>
                <SelectValue placeholder="Choose a session to adjust" />
              </SelectTrigger>
              <SelectContent>
                {completedSessions.map((session) => (
                  <SelectItem key={session.id} value={session.id.toString()}>
                    {new Date(session.date).toLocaleDateString()} - {session.duration || 0} minutes
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          
          <div>
            <Label htmlFor="duration">Actual Minutes Taught</Label>
            <Input
              id="duration"
              type="number"
              placeholder="90"
              value={duration}
              onChange={(e) => setDuration(e.target.value)}
              min="0"
              max="200"
            />
          </div>
          
          <div>
            <Label htmlFor="reason">Reason for Adjustment</Label>
            <Textarea
              id="reason"
              placeholder="Student was sick, arrived late, etc."
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              rows={3}
            />
          </div>
          
          <div className="bg-amber-50 border border-amber-200 rounded-lg p-3">
            <div className="flex items-center space-x-2">
              <i className="fas fa-info-circle text-amber-600"></i>
              <span className="text-sm text-amber-800">
                This adjustment requires parent approval
              </span>
            </div>
          </div>
          
          <div className="flex space-x-3">
            <Button 
              type="button" 
              variant="outline" 
              className="flex-1"
              onClick={onClose}
            >
              Cancel
            </Button>
            <Button 
              type="submit" 
              className="flex-1"
              disabled={adjustSessionMutation.isPending}
            >
              {adjustSessionMutation.isPending ? "Submitting..." : "Submit for Approval"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
