import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { calculateDistance, formatDistance, getDistanceStatus } from "@/lib/geoUtils";
import type { Student } from "@shared/schema";

interface LocationSimulatorProps {
  students: Student[];
  onLocationChange: (lat: number, lng: number) => void;
  currentLocation: { latitude: number; longitude: number } | null;
}

export default function LocationSimulator({ 
  students, 
  onLocationChange, 
  currentLocation 
}: LocationSimulatorProps) {
  const { toast } = useToast();
  const [isSimulating, setIsSimulating] = useState(false);

  const simulateLocation = (student: Student) => {
    if (!student.latitude || !student.longitude) {
      toast({
        title: "Location Not Set",
        description: "This student doesn't have a location configured.",
        variant: "destructive",
      });
      return;
    }

    const lat = parseFloat(student.latitude);
    const lng = parseFloat(student.longitude);
    
    setIsSimulating(true);
    onLocationChange(lat, lng);
    
    toast({
      title: "Location Simulated",
      description: `You are now at ${student.name}'s location`,
    });

    setTimeout(() => setIsSimulating(false), 1000);
  };

  const simulateAwayLocation = () => {
    // Simulate being far away (random location in New York)
    const randomLat = 40.7128 + (Math.random() - 0.5) * 0.1;
    const randomLng = -74.0060 + (Math.random() - 0.5) * 0.1;
    
    setIsSimulating(true);
    onLocationChange(randomLat, randomLng);
    
    toast({
      title: "Location Simulated",
      description: "You are now away from all student locations",
    });

    setTimeout(() => setIsSimulating(false), 1000);
  };

  if (students.length === 0) {
    return (
      <Card className="mb-6">
        <CardContent className="p-6 text-center">
          <div className="text-gray-500">
            <i className="fas fa-info-circle text-2xl mb-2"></i>
            <p>No students found for GPS simulation.</p>
            <p className="text-sm">Add students as a parent, then switch to tutor view.</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="mb-6">
      <CardHeader>
        <CardTitle className="flex items-center space-x-2">
          <i className="fas fa-map-marker-alt text-primary"></i>
          <span>GPS Simulator (For Testing)</span>
        </CardTitle>
      </CardHeader>
      <CardContent>
        {currentLocation && (
          <div className="mb-4 p-3 bg-blue-50 rounded-lg border border-blue-200">
            <div className="text-sm font-medium text-blue-900 mb-1">📍 Your Current Location:</div>
            <div className="text-xs text-blue-700">
              {currentLocation.latitude.toFixed(6)}, {currentLocation.longitude.toFixed(6)}
            </div>
          </div>
        )}
        
        <div className="space-y-3">
          {students.map((student) => {
            let distance = null;
            let distanceStatus = null;
            
            if (currentLocation && student.latitude && student.longitude) {
              const distanceKm = calculateDistance(
                currentLocation.latitude,
                currentLocation.longitude,
                parseFloat(student.latitude),
                parseFloat(student.longitude)
              );
              distance = formatDistance(distanceKm);
              distanceStatus = getDistanceStatus(distanceKm);
            }
            
            return (
              <div key={student.id} className="p-3 bg-gray-50 rounded-lg">
                <div className="flex items-center justify-between">
                  <div className="flex-1">
                    <div className="font-medium text-gray-900">{student.name}</div>
                    <div className="text-sm text-gray-600">{student.homeAddress}</div>
                    {student.latitude && student.longitude && (
                      <div className="text-xs text-gray-500">
                        {parseFloat(student.latitude).toFixed(4)}, {parseFloat(student.longitude).toFixed(4)}
                      </div>
                    )}
                  </div>
                  <Button
                    size="sm"
                    onClick={() => simulateLocation(student)}
                    disabled={isSimulating || !student.latitude}
                    className="ml-3"
                    title={!student.latitude ? "No GPS coordinates available" : "Click to simulate location"}
                  >
                    <i className="fas fa-location-arrow mr-1"></i>
                    {isSimulating ? "..." : "Go Here"}
                  </Button>
                  
                  {/* Debug info */}
                  <div className="text-xs text-gray-400 mt-1">
                    Lat: {student.latitude || 'missing'} | Lng: {student.longitude || 'missing'} | 
                    Disabled: {(isSimulating || !student.latitude).toString()} | 
                    Available: {!!student.latitude ? '✓' : '✗'}
                  </div>
                </div>
                
                {distance && distanceStatus && (
                  <div className={`mt-2 flex items-center space-x-2 text-sm ${distanceStatus.color}`}>
                    <i className={`fas ${distanceStatus.icon}`}></i>
                    <span>
                      Distance: <strong>{distance}</strong>
                      {distanceStatus.status === 'at-location' && ' - Session will auto-start!'}
                      {distanceStatus.status === 'nearby' && ' - Close but not in range'}
                      {distanceStatus.status === 'away' && ' - Too far for auto-start'}
                    </span>
                  </div>
                )}
              </div>
            );
          })}
          
          <div className="flex items-center justify-between p-3 bg-red-50 rounded-lg border border-red-200">
            <div>
              <div className="font-medium text-gray-900">Away from Students</div>
              <div className="text-sm text-gray-600">Simulate being far from any student location</div>
            </div>
            <Button
              size="sm"
              variant="outline"
              onClick={simulateAwayLocation}
              disabled={isSimulating}
              className="ml-3 border-red-300 text-red-700 hover:bg-red-50"
            >
              <i className="fas fa-times mr-1"></i>
              Go Away
            </Button>
          </div>
        </div>

        {currentLocation && (
          <div className="mt-4 p-3 bg-blue-50 rounded-lg border border-blue-200">
            <div className="text-sm font-medium text-blue-900 mb-1">Current Simulated Location:</div>
            <div className="text-xs text-blue-700">
              {currentLocation.latitude.toFixed(4)}, {currentLocation.longitude.toFixed(4)}
            </div>
          </div>
        )}

        <div className="mt-4 p-3 bg-amber-50 rounded-lg border border-amber-200">
          <div className="flex items-center space-x-2 mb-2">
            <i className="fas fa-info-circle text-amber-600"></i>
            <span className="text-sm font-medium text-amber-800">Testing Instructions</span>
          </div>
          <div className="text-sm text-amber-700">
            1. Add a student with their address<br/>
            2. Click "Go Here" to simulate being at that location<br/>
            3. Watch the app automatically start a session<br/>
            4. Click "Go Away" to end the session
          </div>
        </div>
      </CardContent>
    </Card>
  );
}