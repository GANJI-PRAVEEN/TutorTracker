import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { insertStudentSchema } from "@shared/schema";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import type { z } from "zod";

const studentFormSchema = insertStudentSchema.extend({
  name: insertStudentSchema.shape.name.min(1, "Student name is required"),
  homeAddress: insertStudentSchema.shape.homeAddress.min(1, "Home address is required"),
  tutorId: insertStudentSchema.shape.tutorId.min(1, "Tutor ID is required"),
});

type StudentFormData = z.infer<typeof studentFormSchema>;

interface StudentSetupModalProps {
  isOpen: boolean;
  onClose: () => void;
  tutorId: string;
}

export default function StudentSetupModal({ 
  isOpen, 
  onClose, 
  tutorId 
}: StudentSetupModalProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isGeocodingAddress, setIsGeocodingAddress] = useState(false);

  const form = useForm<StudentFormData>({
    resolver: zodResolver(studentFormSchema),
    defaultValues: {
      name: "",
      homeAddress: "",
      tutorId,
      parentId: "", // Will be set by the parent user
      dailyRate: "300",
      expectedDuration: 90,
    },
  });

  const createStudentMutation = useMutation({
    mutationFn: async (data: StudentFormData) => {
      // First try to geocode the address
      setIsGeocodingAddress(true);
      let coordinates = null;
      
      try {
        // Use a simple geocoding approach with browser geolocation for demo
        // In production, you'd use Google Maps Geocoding API or similar
        const response = await fetch(`https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(data.homeAddress)}&limit=1`);
        const results = await response.json();
        
        if (results && results.length > 0) {
          coordinates = {
            latitude: parseFloat(results[0].lat),
            longitude: parseFloat(results[0].lon),
          };
        }
      } catch (error) {
        console.warn("Geocoding failed, continuing without coordinates:", error);
      }
      
      setIsGeocodingAddress(false);

      const studentData = {
        ...data,
        latitude: coordinates?.latitude?.toString(),
        longitude: coordinates?.longitude?.toString(),
        parentId: tutorId,
        tutorId: tutorId, // Assign current user as both tutor and parent
      };

      await apiRequest('POST', '/api/students', studentData);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/students'] });
      toast({
        title: "Student Added",
        description: "Student profile created successfully. GPS tracking is now enabled.",
      });
      onClose();
      form.reset();
    },
    onError: (error) => {
      setIsGeocodingAddress(false);
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: error.message || "Failed to create student profile.",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (data: StudentFormData) => {
    createStudentMutation.mutate(data);
  };

  const fillDemoData = () => {
    form.setValue("name", "John Smith");
    form.setValue("homeAddress", "123 Main Street, New York, NY 10001");
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Add Student</DialogTitle>
        </DialogHeader>
        
        <Form {...form}>
          <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="name"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Student Name</FormLabel>
                  <FormControl>
                    <Input placeholder="Enter student's full name" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="homeAddress"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Home Address</FormLabel>
                  <FormControl>
                    <Textarea
                      placeholder="Enter complete home address including city and postal code"
                      rows={3}
                      {...field}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="dailyRate"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Daily Rate (₹)</FormLabel>
                  <FormControl>
                    <Input type="number" placeholder="300" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-3">
              <div className="flex items-center space-x-2 mb-2">
                <i className="fas fa-info-circle text-blue-600"></i>
                <span className="text-sm font-medium text-blue-800">GPS Tracking</span>
              </div>
              <p className="text-sm text-blue-700">
                The app will automatically detect when you arrive within 100 meters of this address and start the session timer.
              </p>
            </div>

            <div className="bg-amber-50 border border-amber-200 rounded-lg p-3">
              <Button 
                type="button" 
                variant="outline" 
                size="sm" 
                onClick={fillDemoData}
                className="mb-2"
              >
                <i className="fas fa-magic mr-2"></i>
                Fill Demo Data
              </Button>
              <p className="text-xs text-amber-700">
                Click above to test with sample data, or enter real student information.
              </p>
            </div>
            
            <div className="flex space-x-3">
              <Button 
                type="button" 
                variant="outline" 
                className="flex-1"
                onClick={onClose}
              >
                Cancel
              </Button>
              <Button 
                type="submit" 
                className="flex-1"
                disabled={createStudentMutation.isPending || isGeocodingAddress}
              >
                {isGeocodingAddress ? "Finding Location..." : 
                 createStudentMutation.isPending ? "Creating..." : "Add Student"}
              </Button>
            </div>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}