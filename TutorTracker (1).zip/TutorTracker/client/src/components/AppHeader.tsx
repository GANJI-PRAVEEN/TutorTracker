import { Button } from "@/components/ui/button";
import type { User } from "@shared/schema";

interface AppHeaderProps {
  user: User;
  currentRole: 'tutor' | 'parent';
  onRoleSwitch: () => void;
}

export default function AppHeader({ user, currentRole, onRoleSwitch }: AppHeaderProps) {
  return (
    <header className="bg-white border-b border-gray-200 px-4 py-3 sticky top-0 z-50">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 bg-primary rounded-full flex items-center justify-center">
            <i className="fas fa-graduation-cap text-white text-lg"></i>
          </div>
          <div>
            <h1 className="font-semibold text-gray-900 text-lg">TutorTrack</h1>
            <div className="flex items-center space-x-2">
              <span className="text-sm text-gray-600">
                {currentRole === 'tutor' ? 'Tutor View' : 'Parent View'}
              </span>
              {user.roles?.includes('tutor') && user.roles?.includes('parent') && (
                <Button
                  variant="ghost"
                  size="sm"
                  className="text-xs bg-gray-100 px-2 py-1 rounded-full text-gray-700 hover:bg-gray-200 h-auto"
                  onClick={onRoleSwitch}
                >
                  Switch to {currentRole === 'tutor' ? 'Parent' : 'Tutor'}
                </Button>
              )}
            </div>
          </div>
        </div>
        <div className="flex items-center space-x-3">
          <button className="relative">
            <i className="fas fa-bell text-gray-600 text-lg"></i>
            <span className="absolute -top-1 -right-1 w-3 h-3 bg-red-500 rounded-full"></span>
          </button>
          <img 
            src={user.profileImageUrl || "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&w=40&h=40&fit=crop&crop=face"} 
            alt="Profile" 
            className="w-8 h-8 rounded-full object-cover"
          />
        </div>
      </div>
    </header>
  );
}
