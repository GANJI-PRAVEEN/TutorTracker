import { Button } from "@/components/ui/button";
import type { TutoringSession } from "@shared/schema";

interface SessionStatusCardProps {
  activeSession?: TutoringSession;
  currentTime: string;
  isGpsActive: boolean;
  onEndSession: () => void;
  onPauseSession: () => void;
}

export default function SessionStatusCard({ 
  activeSession, 
  currentTime, 
  isGpsActive, 
  onEndSession, 
  onPauseSession 
}: SessionStatusCardProps) {
  if (!activeSession) {
    return (
      <div className="p-4">
        <div className="session-timer rounded-xl p-6 text-white mb-6">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="text-lg font-semibold">No Active Session</h2>
              <p className="text-blue-100 text-sm">
                {new Date().toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
              </p>
            </div>
            <div className="flex items-center space-x-2">
              <div className={`w-2 h-2 rounded-full ${isGpsActive ? 'bg-session-active animate-pulse' : 'bg-gray-400'}`}></div>
              <span className="text-sm">{isGpsActive ? 'GPS Active' : 'GPS Inactive'}</span>
            </div>
          </div>
          
          <div className="text-center mb-4">
            <div className="text-4xl font-bold mb-1">00:00</div>
            <div className="text-blue-100 text-sm">waiting to start</div>
            <div className="mt-2 bg-blue-600 bg-opacity-50 rounded-full h-2">
              <div className="bg-white h-2 rounded-full" style={{ width: '0%' }}></div>
            </div>
            <div className="text-xs text-blue-100 mt-1">Target: 90 minutes</div>
          </div>

          <div className="text-center">
            <p className="text-blue-100 text-sm">Move to student's location to auto-start session</p>
          </div>
        </div>
      </div>
    );
  }

  const minutes = parseInt(currentTime.split(':')[0]);
  const progressPercentage = Math.min((minutes / 90) * 100, 100);

  return (
    <div className="p-4">
      <div className="session-timer rounded-xl p-6 text-white mb-6">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-lg font-semibold">Today's Session</h2>
            <p className="text-blue-100 text-sm">
              {new Date().toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
            </p>
          </div>
          <div className="flex items-center space-x-2">
            <div className={`w-2 h-2 rounded-full ${isGpsActive ? 'bg-session-active animate-pulse' : 'bg-gray-400'}`}></div>
            <span className="text-sm">{isGpsActive ? 'GPS Active' : 'GPS Inactive'}</span>
          </div>
        </div>
        
        <div className="text-center mb-4">
          <div className="text-4xl font-bold mb-1">{currentTime}</div>
          <div className="text-blue-100 text-sm">minutes elapsed</div>
          <div className="mt-2 bg-blue-600 bg-opacity-50 rounded-full h-2">
            <div 
              className="bg-white h-2 rounded-full transition-all duration-300" 
              style={{ width: `${progressPercentage}%` }}
            ></div>
          </div>
          <div className="text-xs text-blue-100 mt-1">Target: 90 minutes</div>
        </div>

        <div className="flex space-x-3">
          <Button 
            variant="ghost"
            className="flex-1 bg-white bg-opacity-20 py-3 rounded-lg font-medium hover:bg-white hover:bg-opacity-30"
            onClick={onPauseSession}
          >
            <i className="fas fa-pause mr-2"></i>Pause
          </Button>
          <Button 
            variant="ghost"
            className="flex-1 bg-white bg-opacity-20 py-3 rounded-lg font-medium hover:bg-white hover:bg-opacity-30"
            onClick={onEndSession}
          >
            <i className="fas fa-stop mr-2"></i>End Session
          </Button>
        </div>
      </div>
    </div>
  );
}
