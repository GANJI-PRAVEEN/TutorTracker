import {
  pgTable,
  text,
  varchar,
  timestamp,
  jsonb,
  index,
  serial,
  integer,
  decimal,
  boolean,
  date,
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from "drizzle-orm";

// Session storage table for express sessions
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// User storage table
export const users = pgTable("users", {
  id: varchar("id").primaryKey().notNull(),
  email: varchar("email").unique(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  roles: varchar("roles").notNull().default("tutor"), // 'tutor', 'parent', 'tutor,parent', 'admin'
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const students = pgTable("students", {
  id: serial("id").primaryKey(),
  name: varchar("name").notNull(),
  homeAddress: text("home_address").notNull(),
  latitude: decimal("latitude", { precision: 10, scale: 8 }),
  longitude: decimal("longitude", { precision: 11, scale: 8 }),
  dailyRate: decimal("daily_rate", { precision: 10, scale: 2 }).notNull().default("300"),
  expectedDuration: integer("expected_duration").notNull().default(90), // minutes
  tutorId: varchar("tutor_id").notNull(),
  parentId: varchar("parent_id").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const sessions_table = pgTable("tutoring_sessions", {
  id: serial("id").primaryKey(),
  studentId: integer("student_id").notNull(),
  tutorId: varchar("tutor_id").notNull(),
  date: date("date").notNull(),
  startTime: timestamp("start_time"),
  endTime: timestamp("end_time"),
  duration: integer("duration"), // actual minutes taught
  expectedDuration: integer("expected_duration").notNull().default(90),
  status: varchar("status").notNull().default("scheduled"), // 'scheduled', 'active', 'completed', 'cancelled'
  autoDetected: boolean("auto_detected").default(false),
  manualAdjustment: boolean("manual_adjustment").default(false),
  adjustmentReason: text("adjustment_reason"),
  parentApproved: boolean("parent_approved").default(false),
  compensation: integer("compensation").default(0), // deficit minutes to compensate
  earnings: decimal("earnings", { precision: 10, scale: 2 }),
  createdAt: timestamp("created_at").defaultNow(),
});

export const compensations = pgTable("compensations", {
  id: serial("id").primaryKey(),
  tutorId: varchar("tutor_id").notNull(),
  studentId: integer("student_id").notNull(),
  deficitDate: date("deficit_date").notNull(),
  deficitMinutes: integer("deficit_minutes").notNull(),
  compensatedDate: date("compensated_date"),
  compensatedMinutes: integer("compensated_minutes").default(0),
  status: varchar("status").notNull().default("pending"), // 'pending', 'partial', 'completed'
  createdAt: timestamp("created_at").defaultNow(),
});

export const notifications = pgTable("notifications", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull(),
  type: varchar("type").notNull(), // 'compensation_reminder', 'session_shortfall', 'approval_request'
  title: varchar("title").notNull(),
  message: text("message").notNull(),
  read: boolean("read").default(false),
  sessionId: integer("session_id"),
  compensationId: integer("compensation_id"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const monthlyReports = pgTable("monthly_reports", {
  id: serial("id").primaryKey(),
  tutorId: varchar("tutor_id").notNull(),
  studentId: integer("student_id").notNull(),
  month: integer("month").notNull(),
  year: integer("year").notNull(),
  totalDays: integer("total_days").notNull(),
  totalMinutes: integer("total_minutes").notNull(),
  totalEarnings: decimal("total_earnings", { precision: 10, scale: 2 }).notNull(),
  compensationMinutes: integer("compensation_minutes").default(0),
  finalPayment: decimal("final_payment", { precision: 10, scale: 2 }),
  generated: boolean("generated").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

// Relations
export const usersRelations = relations(users, ({ many }) => ({
  tutoredStudents: many(students, { relationName: "tutor" }),
  parentedStudents: many(students, { relationName: "parent" }),
  sessions: many(sessions_table),
  compensations: many(compensations),
  notifications: many(notifications),
  monthlyReports: many(monthlyReports),
}));

export const studentsRelations = relations(students, ({ one, many }) => ({
  tutor: one(users, {
    fields: [students.tutorId],
    references: [users.id],
    relationName: "tutor",
  }),
  parent: one(users, {
    fields: [students.parentId],
    references: [users.id],
    relationName: "parent",
  }),
  sessions: many(sessions_table),
  compensations: many(compensations),
  monthlyReports: many(monthlyReports),
}));

export const sessionsRelations = relations(sessions_table, ({ one }) => ({
  student: one(students, {
    fields: [sessions_table.studentId],
    references: [students.id],
  }),
  tutor: one(users, {
    fields: [sessions_table.tutorId],
    references: [users.id],
  }),
}));

export const compensationsRelations = relations(compensations, ({ one }) => ({
  tutor: one(users, {
    fields: [compensations.tutorId],
    references: [users.id],
  }),
  student: one(students, {
    fields: [compensations.studentId],
    references: [students.id],
  }),
}));

export const notificationsRelations = relations(notifications, ({ one }) => ({
  user: one(users, {
    fields: [notifications.userId],
    references: [users.id],
  }),
  session: one(sessions_table, {
    fields: [notifications.sessionId],
    references: [sessions_table.id],
  }),
  compensation: one(compensations, {
    fields: [notifications.compensationId],
    references: [compensations.id],
  }),
}));

export const monthlyReportsRelations = relations(monthlyReports, ({ one }) => ({
  tutor: one(users, {
    fields: [monthlyReports.tutorId],
    references: [users.id],
  }),
  student: one(students, {
    fields: [monthlyReports.studentId],
    references: [students.id],
  }),
}));

// Insert schemas
export const insertUserSchema = createInsertSchema(users).omit({
  createdAt: true,
  updatedAt: true,
});

export const insertStudentSchema = createInsertSchema(students).omit({
  id: true,
  createdAt: true,
});

export const insertSessionSchema = createInsertSchema(sessions_table).omit({
  id: true,
  createdAt: true,
});

export const insertCompensationSchema = createInsertSchema(compensations).omit({
  id: true,
  createdAt: true,
});

export const insertNotificationSchema = createInsertSchema(notifications).omit({
  id: true,
  createdAt: true,
});

export const insertMonthlyReportSchema = createInsertSchema(monthlyReports).omit({
  id: true,
  createdAt: true,
});

// Types
export type UpsertUser = typeof users.$inferInsert;
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type Student = typeof students.$inferSelect;
export type InsertStudent = z.infer<typeof insertStudentSchema>;

export type TutoringSession = typeof sessions_table.$inferSelect;
export type InsertSession = z.infer<typeof insertSessionSchema>;

export type Compensation = typeof compensations.$inferSelect;
export type InsertCompensation = z.infer<typeof insertCompensationSchema>;

export type Notification = typeof notifications.$inferSelect;
export type InsertNotification = z.infer<typeof insertNotificationSchema>;

export type MonthlyReport = typeof monthlyReports.$inferSelect;
export type InsertMonthlyReport = z.infer<typeof insertMonthlyReportSchema>;
