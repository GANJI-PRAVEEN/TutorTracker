import express, { RequestHandler } from 'express';
import session from 'express-session';
import connectPg from 'connect-pg-simple';
import { storage } from './storage';

// Simple authentication middleware for standalone version
// Replace this with your preferred authentication method (OAuth, JWT, etc.)

export function getSession() {
  const sessionTtl = 7 * 24 * 60 * 60 * 1000; // 1 week
  const pgStore = connectPg(session);
  
  const sessionStore = new pgStore({
    conString: process.env.DATABASE_URL,
    createTableIfMissing: false,
    ttl: sessionTtl,
    tableName: "sessions",
  });
  
  return session({
    secret: process.env.SESSION_SECRET!,
    store: sessionStore,
    resave: false,
    saveUninitialized: false,
    cookie: {
      httpOnly: true,
      secure: false, // Set to true in production with HTTPS
      maxAge: sessionTtl,
    },
  });
}

// Simple authentication setup for development
export async function setupAuth(app: express.Express) {
  app.use(getSession());
  
  // Simple login endpoint - replace with your authentication method
  app.post('/api/auth/login', async (req, res) => {
    try {
      const { username, password } = req.body;
      
      // For development - create/login as test user
      // In production, implement proper authentication
      const testUser = {
        id: 'tutortrack-user-123',
        email: username || 'test@tutortrack.com',
        firstName: 'Test',
        lastName: 'User',
        profileImageUrl: null,
        roles: 'tutor,parent',
      };
      
      // Create user if not exists
      let user = await storage.getUser(testUser.id);
      if (!user) {
        user = await storage.upsertUser(testUser);
      }
      
      // Set session
      (req.session as any).user = {
        id: user.id,
        claims: { sub: user.id },
        email: user.email,
        firstName: user.firstName,
        lastName: user.lastName,
        roles: user.roles?.split(',') || ['tutor'],
      };
      
      res.json({ success: true, user: user });
    } catch (error) {
      console.error('Login error:', error);
      res.status(500).json({ message: 'Login failed' });
    }
  });
  
  // Logout endpoint
  app.post('/api/auth/logout', (req, res) => {
    req.session.destroy((err) => {
      if (err) {
        return res.status(500).json({ message: 'Logout failed' });
      }
      res.json({ success: true });
    });
  });
  
  // Auto-login for development - creates a test user session
  app.get('/api/auth/auto-login', async (req, res) => {
    try {
      const testUser = {
        id: 'tutortrack-user-123',
        email: 'test@tutortrack.com',
        firstName: 'Test',
        lastName: 'User',
        profileImageUrl: null,
        roles: 'tutor,parent',
      };
      
      let user = await storage.getUser(testUser.id);
      if (!user) {
        user = await storage.upsertUser(testUser);
      }
      
      (req.session as any).user = {
        id: user.id,
        claims: { sub: user.id },
        email: user.email,
        firstName: user.firstName,
        lastName: user.lastName,
        roles: user.roles?.split(',') || ['tutor'],
      };
      
      res.json({ success: true, user: user });
    } catch (error) {
      console.error('Auto-login error:', error);
      res.status(500).json({ message: 'Auto-login failed' });
    }
  });
}

// Authentication middleware
export const isAuthenticated: RequestHandler = async (req, res, next) => {
  const sessionUser = (req.session as any)?.user;
  
  if (!sessionUser) {
    return res.status(401).json({ message: "Unauthorized" });
  }
  
  // Attach user to request for compatibility
  req.user = sessionUser;
  next();
};

// Simple middleware to auto-authenticate for development
export const autoAuth: RequestHandler = async (req, res, next) => {
  const sessionUser = (req.session as any)?.user;
  
  if (!sessionUser) {
    // Auto-create session for development
    try {
      const testUser = {
        id: 'tutortrack-user-123',
        email: 'test@tutortrack.com',
        firstName: 'Test',
        lastName: 'User',
        profileImageUrl: null,
        roles: 'tutor,parent',
      };
      
      let user = await storage.getUser(testUser.id);
      if (!user) {
        user = await storage.upsertUser(testUser);
      }
      
      (req.session as any).user = {
        id: user.id,
        claims: { sub: user.id },
        email: user.email,
        firstName: user.firstName,
        lastName: user.lastName,
        roles: user.roles?.split(',') || ['tutor'],
      };
      
      req.user = (req.session as any).user;
    } catch (error) {
      console.error('Auto-auth error:', error);
      return res.status(500).json({ message: "Authentication failed" });
    }
  } else {
    req.user = sessionUser;
  }
  
  next();
};