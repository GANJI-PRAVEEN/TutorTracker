import type { User } from "@shared/schema";

export function hasRole(user: User, role: string): boolean {
  if (!user.roles) return false;
  return user.roles.split(',').includes(role);
}

export function addRole(user: User, role: string): string {
  if (!user.roles) return role;
  const roles = user.roles.split(',');
  if (!roles.includes(role)) {
    roles.push(role);
  }
  return roles.join(',');
}

export function getUserDisplayRole(user: User): string {
  if (!user.roles) return 'tutor';
  const roles = user.roles.split(',');
  if (roles.includes('admin')) return 'admin';
  if (roles.length > 1) return 'tutor'; // Default to tutor for display
  return roles[0];
}