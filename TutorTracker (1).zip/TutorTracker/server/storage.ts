import {
  users,
  students,
  sessions_table,
  compensations,
  notifications,
  monthlyReports,
  type User,
  type UpsertUser,
  type Student,
  type InsertStudent,
  type TutoringSession,
  type InsertSession,
  type Compensation,
  type InsertCompensation,
  type Notification,
  type InsertNotification,
  type MonthlyReport,
  type InsertMonthlyReport,
} from "@shared/schema";
import { db } from "./db";
import { eq, and, gte, lte, desc, asc } from "drizzle-orm";

export interface IStorage {
  // User operations (mandatory for Replit Auth)
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  updateUserRoles(id: string, roles: string): Promise<User>;
  
  // Student operations
  getStudentsByTutorId(tutorId: string): Promise<Student[]>;
  getStudentsByParentId(parentId: string): Promise<Student[]>;
  createStudent(student: InsertStudent): Promise<Student>;
  updateStudent(id: number, updates: Partial<InsertStudent>): Promise<Student>;
  
  // Session operations
  getSessionsByTutorId(tutorId: string, limit?: number): Promise<TutoringSession[]>;
  getSessionsByStudentId(studentId: number, limit?: number): Promise<TutoringSession[]>;
  getSessionByDate(studentId: number, date: string): Promise<TutoringSession | undefined>;
  createSession(session: InsertSession): Promise<TutoringSession>;
  updateSession(id: number, updates: Partial<InsertSession>): Promise<TutoringSession>;
  getActiveSession(tutorId: string): Promise<TutoringSession | undefined>;
  
  // Compensation operations
  getPendingCompensations(tutorId: string): Promise<Compensation[]>;
  createCompensation(compensation: InsertCompensation): Promise<Compensation>;
  updateCompensation(id: number, updates: Partial<InsertCompensation>): Promise<Compensation>;
  
  // Notification operations
  getNotifications(userId: string, unreadOnly?: boolean): Promise<Notification[]>;
  createNotification(notification: InsertNotification): Promise<Notification>;
  markNotificationRead(id: number): Promise<void>;
  
  // Report operations
  getMonthlyReport(tutorId: string, studentId: number, month: number, year: number): Promise<MonthlyReport | undefined>;
  createMonthlyReport(report: InsertMonthlyReport): Promise<MonthlyReport>;
  
  // Analytics
  getWeeklyStats(tutorId: string, startDate: string, endDate: string): Promise<{
    totalMinutes: number;
    totalEarnings: number;
    daysActive: number;
    compensationMinutes: number;
  }>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  async updateUserRoles(id: string, roles: string): Promise<User> {
    const [user] = await db
      .update(users)
      .set({ roles, updatedAt: new Date() })
      .where(eq(users.id, id))
      .returning();
    return user;
  }

  // Student operations
  async getStudentsByTutorId(tutorId: string): Promise<Student[]> {
    return await db.select().from(students).where(eq(students.tutorId, tutorId));
  }

  async getStudentsByParentId(parentId: string): Promise<Student[]> {
    return await db.select().from(students).where(eq(students.parentId, parentId));
  }

  async createStudent(student: InsertStudent): Promise<Student> {
    const [newStudent] = await db.insert(students).values(student).returning();
    return newStudent;
  }

  async updateStudent(id: number, updates: Partial<InsertStudent>): Promise<Student> {
    const [updatedStudent] = await db
      .update(students)
      .set(updates)
      .where(eq(students.id, id))
      .returning();
    return updatedStudent;
  }

  // Session operations
  async getSessionsByTutorId(tutorId: string, limit = 50): Promise<TutoringSession[]> {
    return await db
      .select()
      .from(sessions_table)
      .where(eq(sessions_table.tutorId, tutorId))
      .orderBy(desc(sessions_table.date))
      .limit(limit);
  }

  async getSessionsByStudentId(studentId: number, limit = 50): Promise<TutoringSession[]> {
    return await db
      .select()
      .from(sessions_table)
      .where(eq(sessions_table.studentId, studentId))
      .orderBy(desc(sessions_table.date))
      .limit(limit);
  }

  async getSessionByDate(studentId: number, date: string): Promise<TutoringSession | undefined> {
    const [session] = await db
      .select()
      .from(sessions_table)
      .where(and(eq(sessions_table.studentId, studentId), eq(sessions_table.date, date)));
    return session;
  }

  async createSession(session: InsertSession): Promise<TutoringSession> {
    const [newSession] = await db.insert(sessions_table).values(session).returning();
    return newSession;
  }

  async updateSession(id: number, updates: Partial<InsertSession>): Promise<TutoringSession> {
    const [updatedSession] = await db
      .update(sessions_table)
      .set(updates)
      .where(eq(sessions_table.id, id))
      .returning();
    return updatedSession;
  }

  async getActiveSession(tutorId: string): Promise<TutoringSession | undefined> {
    const [session] = await db
      .select()
      .from(sessions_table)
      .where(and(eq(sessions_table.tutorId, tutorId), eq(sessions_table.status, "active")));
    return session;
  }

  // Compensation operations
  async getPendingCompensations(tutorId: string): Promise<Compensation[]> {
    return await db
      .select()
      .from(compensations)
      .where(and(eq(compensations.tutorId, tutorId), eq(compensations.status, "pending")))
      .orderBy(asc(compensations.deficitDate));
  }

  async createCompensation(compensation: InsertCompensation): Promise<Compensation> {
    const [newCompensation] = await db.insert(compensations).values(compensation).returning();
    return newCompensation;
  }

  async updateCompensation(id: number, updates: Partial<InsertCompensation>): Promise<Compensation> {
    const [updatedCompensation] = await db
      .update(compensations)
      .set(updates)
      .where(eq(compensations.id, id))
      .returning();
    return updatedCompensation;
  }

  // Notification operations
  async getNotifications(userId: string, unreadOnly = false): Promise<Notification[]> {
    const conditions = [eq(notifications.userId, userId)];
    if (unreadOnly) {
      conditions.push(eq(notifications.read, false));
    }

    return await db
      .select()
      .from(notifications)
      .where(and(...conditions))
      .orderBy(desc(notifications.createdAt));
  }

  async createNotification(notification: InsertNotification): Promise<Notification> {
    const [newNotification] = await db.insert(notifications).values(notification).returning();
    return newNotification;
  }

  async markNotificationRead(id: number): Promise<void> {
    await db.update(notifications).set({ read: true }).where(eq(notifications.id, id));
  }

  // Report operations
  async getMonthlyReport(
    tutorId: string,
    studentId: number,
    month: number,
    year: number
  ): Promise<MonthlyReport | undefined> {
    const [report] = await db
      .select()
      .from(monthlyReports)
      .where(
        and(
          eq(monthlyReports.tutorId, tutorId),
          eq(monthlyReports.studentId, studentId),
          eq(monthlyReports.month, month),
          eq(monthlyReports.year, year)
        )
      );
    return report;
  }

  async createMonthlyReport(report: InsertMonthlyReport): Promise<MonthlyReport> {
    const [newReport] = await db.insert(monthlyReports).values(report).returning();
    return newReport;
  }

  // Analytics
  async getWeeklyStats(tutorId: string, startDate: string, endDate: string): Promise<{
    totalMinutes: number;
    totalEarnings: number;
    daysActive: number;
    compensationMinutes: number;
  }> {
    const sessions = await db
      .select()
      .from(sessions_table)
      .where(
        and(
          eq(sessions_table.tutorId, tutorId),
          gte(sessions_table.date, startDate),
          lte(sessions_table.date, endDate),
          eq(sessions_table.status, "completed")
        )
      );

    const pendingCompensations = await db
      .select()
      .from(compensations)
      .where(and(eq(compensations.tutorId, tutorId), eq(compensations.status, "pending")));

    const totalMinutes = sessions.reduce((sum, session) => sum + (session.duration || 0), 0);
    const totalEarnings = sessions.reduce((sum, session) => sum + Number(session.earnings || 0), 0);
    const daysActive = sessions.length;
    const compensationMinutes = pendingCompensations.reduce(
      (sum, comp) => sum + comp.deficitMinutes,
      0
    );

    return {
      totalMinutes,
      totalEarnings,
      daysActive,
      compensationMinutes,
    };
  }
}

export const storage = new DatabaseStorage();
