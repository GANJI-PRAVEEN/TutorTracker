import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth, isAuthenticated, autoAuth } from "./auth";
import { insertSessionSchema, insertStudentSchema, insertCompensationSchema } from "@shared/schema";
import { hasRole, addRole, getUserDisplayRole } from "./utils/roleUtils";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth middleware
  await setupAuth(app);

  // Auth routes
  app.get('/api/auth/user', autoAuth, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Student routes
  app.get('/api/students', autoAuth, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      let students;
      if (hasRole(user, 'tutor')) {
        students = await storage.getStudentsByTutorId(userId);
      } else if (hasRole(user, 'parent')) {
        students = await storage.getStudentsByParentId(userId);
      } else {
        return res.status(403).json({ message: "Unauthorized role" });
      }

      res.json(students);
    } catch (error) {
      console.error("Error fetching students:", error);
      res.status(500).json({ message: "Failed to fetch students" });
    }
  });

  app.post('/api/students', autoAuth, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      if (!user || !hasRole(user, 'parent')) {
        // Automatically add parent role if user is creating a student
        if (user) {
          const updatedRoles = addRole(user, 'parent');
          await storage.updateUserRoles(userId, updatedRoles);
        } else {
          return res.status(404).json({ message: "User not found" });
        }
      }

      const studentData = insertStudentSchema.parse({
        ...req.body,
        parentId: userId,
      });

      const student = await storage.createStudent(studentData);
      res.json(student);
    } catch (error) {
      console.error("Error creating student:", error);
      res.status(500).json({ message: "Failed to create student" });
    }
  });

  // Session routes
  app.get('/api/sessions', autoAuth, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      let sessions;
      if (hasRole(user, 'tutor')) {
        sessions = await storage.getSessionsByTutorId(userId, 20);
      } else if (hasRole(user, 'parent')) {
        const students = await storage.getStudentsByParentId(userId);
        const allSessions = await Promise.all(
          students.map(student => storage.getSessionsByStudentId(student.id, 10))
        );
        sessions = allSessions.flat().sort((a, b) => 
          new Date(b.date).getTime() - new Date(a.date).getTime()
        );
      } else {
        return res.status(403).json({ message: "Unauthorized role" });
      }

      res.json(sessions);
    } catch (error) {
      console.error("Error fetching sessions:", error);
      res.status(500).json({ message: "Failed to fetch sessions" });
    }
  });

  app.get('/api/sessions/active', autoAuth, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const activeSession = await storage.getActiveSession(userId);
      res.json(activeSession || null);
    } catch (error) {
      console.error("Error fetching active session:", error);
      res.status(500).json({ message: "Failed to fetch active session" });
    }
  });

  app.post('/api/sessions/start', autoAuth, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { studentId, autoDetected = true } = req.body;
      
      // Check if there's already an active session
      const activeSession = await storage.getActiveSession(userId);
      if (activeSession) {
        return res.status(400).json({ message: "Session already active" });
      }

      const today = new Date().toISOString().split('T')[0];
      
      // Check if session already exists for today
      const existingSession = await storage.getSessionByDate(studentId, today);
      if (existingSession) {
        return res.status(400).json({ message: "Session already exists for today" });
      }

      const sessionData = insertSessionSchema.parse({
        studentId,
        tutorId: userId,
        date: today,
        startTime: new Date(),
        status: "active",
        autoDetected,
        expectedDuration: 90,
      });

      const session = await storage.createSession(sessionData);
      res.json(session);
    } catch (error) {
      console.error("Error starting session:", error);
      res.status(500).json({ message: "Failed to start session" });
    }
  });

  app.post('/api/sessions/:id/end', autoAuth, async (req: any, res) => {
    try {
      const sessionId = parseInt(req.params.id);
      const { duration } = req.body;
      
      console.log(`Ending session ${sessionId} with duration:`, duration);
      
      if (!duration || duration < 1) {
        return res.status(400).json({ message: "Invalid duration" });
      }
      
      const endTime = new Date();
      const earnings = duration >= 90 ? 300 : Math.floor((duration / 90) * 300);
      
      const session = await storage.updateSession(sessionId, {
        endTime,
        duration,
        status: "completed",
        earnings: earnings.toString(),
      });

      // Create compensation if needed
      if (duration < 90) {
        const deficitMinutes = 90 - duration;
        await storage.createCompensation({
          tutorId: session.tutorId,
          studentId: session.studentId,
          deficitDate: session.date,
          deficitMinutes,
          status: "pending",
        });

        // Create notification
        await storage.createNotification({
          userId: session.tutorId,
          type: "session_shortfall",
          title: "Session Shortfall",
          message: `You need to compensate ${deficitMinutes} minutes from today's session.`,
          sessionId: session.id,
        });
      }

      res.json(session);
    } catch (error) {
      console.error("Error ending session:", error);
      res.status(500).json({ message: "Failed to end session" });
    }
  });

  app.post('/api/sessions/:id/adjust', autoAuth, async (req: any, res) => {
    try {
      const sessionId = parseInt(req.params.id);
      const { duration, reason } = req.body;
      
      const session = await storage.updateSession(sessionId, {
        duration,
        manualAdjustment: true,
        adjustmentReason: reason,
        parentApproved: false,
      });

      // Create notification for parent approval
      const students = await storage.getStudentsByTutorId(session.tutorId);
      const student = students.find(s => s.id === session.studentId);
      
      if (student) {
        await storage.createNotification({
          userId: student.parentId,
          type: "approval_request",
          title: "Manual Adjustment Request",
          message: `Tutor has requested to adjust session duration. Reason: ${reason}`,
          sessionId: session.id,
        });
      }

      res.json(session);
    } catch (error) {
      console.error("Error adjusting session:", error);
      res.status(500).json({ message: "Failed to adjust session" });
    }
  });

  // Compensation routes
  app.get('/api/compensations', autoAuth, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const compensations = await storage.getPendingCompensations(userId);
      res.json(compensations);
    } catch (error) {
      console.error("Error fetching compensations:", error);
      res.status(500).json({ message: "Failed to fetch compensations" });
    }
  });

  // Notification routes
  app.get('/api/notifications', autoAuth, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const unreadOnly = req.query.unread === 'true';
      const notifications = await storage.getNotifications(userId, unreadOnly);
      res.json(notifications);
    } catch (error) {
      console.error("Error fetching notifications:", error);
      res.status(500).json({ message: "Failed to fetch notifications" });
    }
  });

  app.post('/api/notifications/:id/read', autoAuth, async (req: any, res) => {
    try {
      const notificationId = parseInt(req.params.id);
      await storage.markNotificationRead(notificationId);
      res.json({ success: true });
    } catch (error) {
      console.error("Error marking notification as read:", error);
      res.status(500).json({ message: "Failed to mark notification as read" });
    }
  });

  // Analytics routes
  app.get('/api/analytics/weekly', autoAuth, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const today = new Date();
      const startOfWeek = new Date(today);
      startOfWeek.setDate(today.getDate() - today.getDay());
      const endOfWeek = new Date(startOfWeek);
      endOfWeek.setDate(startOfWeek.getDate() + 6);

      const stats = await storage.getWeeklyStats(
        userId,
        startOfWeek.toISOString().split('T')[0],
        endOfWeek.toISOString().split('T')[0]
      );

      res.json(stats);
    } catch (error) {
      console.error("Error fetching weekly stats:", error);
      res.status(500).json({ message: "Failed to fetch weekly stats" });
    }
  });

  // GPS validation endpoint
  app.post('/api/validate-location', autoAuth, async (req: any, res) => {
    try {
      const { latitude, longitude, studentId } = req.body;
      const userId = req.user.claims.sub;
      
      const students = await storage.getStudentsByTutorId(userId);
      const student = students.find(s => s.id === studentId);
      
      if (!student || !student.latitude || !student.longitude) {
        return res.status(400).json({ message: "Student location not configured" });
      }

      // Calculate distance using Haversine formula
      const R = 6371e3; // Earth's radius in meters
      const φ1 = Number(student.latitude) * Math.PI/180;
      const φ2 = latitude * Math.PI/180;
      const Δφ = (latitude - Number(student.latitude)) * Math.PI/180;
      const Δλ = (longitude - Number(student.longitude)) * Math.PI/180;

      const a = Math.sin(Δφ/2) * Math.sin(Δφ/2) +
                Math.cos(φ1) * Math.cos(φ2) *
                Math.sin(Δλ/2) * Math.sin(Δλ/2);
      const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));

      const distance = R * c; // in meters
      const isAtLocation = distance <= 100; // within 100 meters

      res.json({ 
        isAtLocation, 
        distance: Math.round(distance),
        studentAddress: student.homeAddress 
      });
    } catch (error) {
      console.error("Error validating location:", error);
      res.status(500).json({ message: "Failed to validate location" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
